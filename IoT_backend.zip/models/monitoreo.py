from pydantic import BaseModel

class Monitoreo(BaseModel):
    lugar: str
    temperatura: float
    humedad: float

