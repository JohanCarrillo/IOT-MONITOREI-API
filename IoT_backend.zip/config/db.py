from pymongo import MongoClient

uri = 'mongodb+srv://johan:johan@monitoreo.jirbtlb.mongodb.net/?retryWrites=true&w=majority'

conn = MongoClient(uri)
