def monitoreoEntity(item) -> dict:
    return {
        "lugar": str(item["lugar"]),
        "temperatura": item["temperatura"],
        "humedad": item["humedad"],
    }

def muchosMonitoreosEntity(items) -> list:
    return [monitoreoEntity(item) for item in items]